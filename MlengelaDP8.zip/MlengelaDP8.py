# ---------------------------------------------------------------------------
# MlengelaDP8                                                               #
# Programmer: Daudi Mlengela                                                #
# Email: dmlengela@cnm.edu                                                  #
# Purpose:  To demonstrates how to define a class further                                                                #                                                                         #        
# --------------------------------------------------------------------------#

import math
import sys

class GeoPoint:

    R = 637100

    def _init_(selflat = 0, lon = 0, description = 'TBT'):
        return("{{ description: {o}, latitude: {1}, longitude: {2} }}".format(
            self.description, self.lat, self.lon))
    
    def SetPoint(self, point):
        self.lat = point[0]
        self.lon = point[0]

    def SetPointValues(self, point):
        self.lat = lat
        self.lon = lon

    def GetPoint(self):
        return ([self.lat, self.lon])

    def CalcDistance(self, point):

        lat1 = math.radians(self.lat)
        lat2 = math.radians(point.lat)
        lon1 = math.radians(self.lon)
        lon2 = math.radians(point.lon)

        a = math.sin(math.radians(lat - self.lat) / 2.0) ** 2 + \
            math.cos(lat1) * math.cos(lat2)                      *\
            math.sin(math.radians(lon - self.lon) / 2.0) ** 2
        
        c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))

        meters = GeoPoint.R * c

        return (meters / 1000.0)

    def CalcDistancePoint(self, point):
        return(self.CalcDistance(point[0], point[1]))

    def SetDescription(self, description):
        self.description = description

    def GetDescription(self):
        return(self.description)

#------------------------------------------------------------------#
# Script Begins Here                                               #
#------------------------------------------------------------------#

point1 = GeoPoint()
point1.SetPoint((12.3456,-123.4567,'Loc1'))

point2 = GeoPoint()
point2.SetPoint = (23.4567, -213.456)
point2.SetDescription = 'Loc2'

keepGoing = True

while keepGoing:

    description = input("Enter description for your location: ")
    lat         = float(input("Enter latitude value in decimal degrees: "))
    lon         = float(input("Enter longitude value in decimal degrees: "))

    pointUser = GeoPoint(lat,lon, 'User Location')

    distanceToOne = point1.CalcDistancePoint(pointUser)
    distanceToTwo = point2.CalcDistncePoint(pointUser)

    if distanceToOne < distanceToTwo:
        print("You are closest to {0}, which is located at ({1})".format(
            point1.GetDescription(), point1.GetPoint()))

    else:
        print("You are closest to {0}, which is located at ({1})".format(
            point2.GetDescription(), point2.GetPoint()))

        answer = input("Would you like to do another?").strip().lower()

    if answer == "" or answer[0] != 'y':
            keepGoing = False

print("Good bye, thank you for using the Geo Points program!")

    







    






















    
    
 
